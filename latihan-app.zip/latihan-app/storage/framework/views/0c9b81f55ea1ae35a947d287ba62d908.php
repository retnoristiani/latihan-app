 
<?php $__env->startSection('title', 'Daftar Rak Buku'); ?> 
<?php $__env->startSection('content'); ?> 

    <h2><?php echo e($store); ?> Data Rak Buku</h2>
    <form method="POST" action="<?php echo e($action); ?>"> 
        <?php echo csrf_field(); ?> 
        <?php if(strtolower($store) == 'ubah'): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>
        <input type="hidden" name="id" value="<?php echo e($rak->id); ?>" />
        <input type="text" class="mail_text" name="nama" placeholder="Nama Rak" value="<?php echo e($rak->nama); ?>" /><br>
        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <b><?php echo e($message); ?></b>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input typr="text" class="mail_text" name="lokasi" placeholder="Lokasi" value="<?php echo e($rak->lokasi); ?>" /><br>
        <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <b><?php echo e($message); ?></b>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <input type="text" class="mail_text" name="keterangan" placeholder="Keterangan" value="<?php echo e($rak->keterangan); ?>" />
        <input type="submit" value="<?php echo e($store); ?>" />
        <div class="send_bt">
            <a href="<?php echo e(url('/rak_buku')); ?>">Kembali</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\4899\latihan-app\resources\views/rak_buku/form.blade.php ENDPATH**/ ?>