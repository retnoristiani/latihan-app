<!-- hello.blade.php -->
<h2>Selamat Datang</h2>
<b>Semoga sukses dan lanjar belajar Laravel Framework 10.x</b>

<form method="POST" action="">
    <table>
        <tr>
            <td>NIM</td>
            <td>:</td>
            <td><input type="text" name="nim" value="" /></td>
        </tr>
        <tr>
            <td>Nama</td>
            <td>:</td>
            <td><input type="text" name="nama" value="" /></td>
        </tr>
        <tr>
            <td>Email</td>
            <td>:</td>
            <td><input type="text" name="email" value="" /></td>
        </tr>
        <tr>
            <td><input type="submit" name="btn_submit" value="Simpan" /></td>
            <td></td>
            <td><input type="reset" name="btn_cancel" value="Batal" /></td>
        </tr>
    </table>
</form><?php /**PATH D:\dev-frame\02\latihan-app\resources\views/hello.blade.php ENDPATH**/ ?>