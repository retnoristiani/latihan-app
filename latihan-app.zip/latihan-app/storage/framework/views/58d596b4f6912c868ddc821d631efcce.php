 <?php $__env->startSection('title', 'Daftar Rak Buku'); ?> <?php $__env->startSection('content'); ?> <h2>Daftar Rak Buku</h2>
<div class="send_bt"> <a href="<?php echo e(url('rak_buku/create')); ?>">Tambah</a> </div>
<table>
    <tr>
        <th>No.</th>
        <th>ID</th>
        <th>Nama Rak</th>
        <th>Lokasi</th>
        <th>Keterangan</th>
        <th>Aksi</th>
    </tr> <?php $i = 1; ?> <?php $__currentLoopData = $rak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i); ?></td>
            <td><?php echo e($r->id); ?></td>
            <td><?php echo e($r->nama); ?></td>
            <td><?php echo e($r->lokasi); ?></td>
            <td><?php echo e($r->keterangan); ?></td>
            <td> <a href="rak_buku/<?php echo e($r->id); ?>/edit">Edit</a> <a href="rak_buku/<?php echo e($r->id); ?>">Hapus</a>
            </td>
        </tr> <?php $i++; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table> <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dev-frame\02\latihan-app\resources\views/rak_buku/index.blade.php ENDPATH**/ ?>